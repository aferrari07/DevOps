# -*- coding: utf-8 -*-
# Exercícios by Nick Parlante (CodingBat)

# E. hello_name
# seja uma string name
# hello_name('Bob') -> 'Hello Bob!'
# hello_name('Alice') -> 'Hello Alice!'
# hello_name('X') -> 'Hello X!'
def hello_name(name):
  return 

def test_ex05():
  print ('Hello Name')
  assert hello_name('Bob') == 'Hello Bob!'
  assert hello_name('Alice') == 'Hello Alice!'
  assert hello_name('X') == 'Hello X!'
  assert hello_name('Hello') == 'Hello Hello!'


